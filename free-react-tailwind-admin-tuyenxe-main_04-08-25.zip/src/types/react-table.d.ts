declare module 'react-table';
